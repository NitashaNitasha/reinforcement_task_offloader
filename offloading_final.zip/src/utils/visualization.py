import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import logging

logger = logging.getLogger(__name__)

def setup_plot_style():
    """Set up the plot style for premium publication-quality visualization"""
    # Use a modern, minimalist style
    plt.style.use('seaborn-v0_8-whitegrid')

    # Configure elegant fonts and styling for high-impact academic publishing
    plt.rcParams.update({
        'font.family': 'Arial',
        'font.size': 13,  # Slightly smaller base font for cleaner look
        'axes.labelsize': 15,
        'axes.titlesize': 16,  # Less bulky title
        'xtick.labelsize': 12,
        'ytick.labelsize': 12,
        'legend.fontsize': 12,
        'figure.titlesize': 18,
        'figure.figsize': (12, 8),  # Wider aspect ratio for modern displays
        'figure.dpi': 300,
        'savefig.dpi': 600,  # High DPI for publication
        'axes.grid': True,
        'grid.alpha': 0.2,  # Subtler grid
        'lines.linewidth': 2.0,  # Slightly thinner lines for elegance
        'axes.spines.top': False,
        'axes.spines.right': False,
        'axes.edgecolor': '#444444',  # Darker edge color
        'axes.linewidth': 1.2,  # Slightly thicker axis lines
        'axes.labelweight': 'medium',  # Slightly bolder labels
        'legend.framealpha': 0.8,  # More visible legends
        'axes.prop_cycle': plt.cycler('color', ['#0173B2', '#DE8F05', '#029E73', '#D55E00',
                                              '#CC78BC', '#CA9161', '#FBAFE4', '#949494']),  # Premium color palette
    })

    # Set figure background to very subtle off-white for elegant look
    plt.rcParams['figure.facecolor'] = '#FAFAFA'
    plt.rcParams['axes.facecolor'] = '#FAFAFA'

def plot_training_curves(stats_df, output_dir='results/figures'):
    """
    Generate publication-quality training curve plots

    Args:
        stats_df: DataFrame with training statistics
        output_dir: Directory to save figures
    """
    setup_plot_style()

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # 1. REWARD AND LATENCY PLOT (DUAL Y-AXIS)
    fig, ax1 = plt.subplots(figsize=(12, 7.5))

    # Use premium color scheme
    reward_color = '#0173B2'  # Rich blue
    latency_color = '#DE8F05'  # Premium amber

    # Plot reward with confidence interval - sleeker design
    ax1.set_xlabel('Training Epoch', fontweight='medium')
    ax1.set_ylabel('Agent Reward', fontweight='medium', color=reward_color)

    # Plot reward line with elegant markers
    epochs = stats_df['epoch']
    reward_mean = stats_df['reward_mean']
    reward_std = stats_df['reward_std']

    # Create gradient effect for premium look
    gradient = np.linspace(0.3, 0.9, len(epochs))
    points = np.array([epochs, reward_mean]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    # Create line collection with gradient colors
    from matplotlib.collections import LineCollection
    norm = plt.Normalize(0, 1)
    lc = LineCollection(segments, cmap='Blues', norm=norm)
    lc.set_array(gradient)
    lc.set_linewidth(3)
    line = ax1.add_collection(lc)

    # Add elegant markers
    ax1.scatter(epochs[::5], reward_mean[::5], color=reward_color, s=60,
                marker='o', edgecolor='white', linewidth=1.5, zorder=3, label='Reward')

    # Add refined confidence interval
    ax1.fill_between(
        epochs,
        reward_mean - reward_std,
        reward_mean + reward_std,
        color=reward_color, alpha=0.1
    )

    # Add subtle grid
    ax1.grid(True, linestyle='--', alpha=0.2)
    ax1.tick_params(axis='y', labelcolor=reward_color)

    # Plot latency on secondary axis with complementary styling
    ax2 = ax1.twinx()
    ax2.set_ylabel('Task Latency (s)', fontweight='medium', color=latency_color)

    # Plot latency with sleeker styling
    latency_mean = stats_df['latency_mean']
    latency_std = stats_df['latency_std']

    # Create gradient for latency line
    latency_gradient = np.linspace(0.3, 0.9, len(epochs))
    latency_points = np.array([epochs, latency_mean]).T.reshape(-1, 1, 2)
    latency_segments = np.concatenate([latency_points[:-1], latency_points[1:]], axis=1)

    # Create line collection with gradient colors
    latency_lc = LineCollection(latency_segments, cmap='Oranges', norm=norm)
    latency_lc.set_array(latency_gradient)
    latency_lc.set_linewidth(2.5)
    latency_line = ax2.add_collection(latency_lc)

    # Add elegant markers for latency line
    ax2.scatter(epochs[::5], latency_mean[::5], color=latency_color, s=60,
               marker='s', edgecolor='white', linewidth=1.5, zorder=3, label='Latency')

    # Add refined confidence interval
    ax2.fill_between(
        epochs,
        latency_mean - latency_std,
        latency_mean + latency_std,
        color=latency_color, alpha=0.1
    )

    # Adjust tick parameters for clarity
    ax2.tick_params(axis='y', labelcolor=latency_color)

    # Clean up the plot limits for better proportions
    y1_min, y1_max = ax1.get_ylim()
    y2_min, y2_max = ax2.get_ylim()
    ax1.set_ylim(y1_min - 0.05 * (y1_max - y1_min), y1_max + 0.05 * (y1_max - y1_min))
    ax2.set_ylim(y2_min - 0.05 * (y2_max - y2_min), y2_max + 0.05 * (y2_max - y2_min))

    # Add title with cleaner styling
    title = 'Task Offloading Performance'
    plt.title(title, fontsize=16, fontweight='medium', pad=15)

    # Create more elegant legend
    from matplotlib.lines import Line2D
    custom_lines = [
        Line2D([0], [0], color=reward_color, lw=3, marker='o', markersize=8, markerfacecolor=reward_color, markeredgecolor='white'),
        Line2D([0], [0], color=latency_color, lw=3, marker='s', markersize=8, markerfacecolor=latency_color, markeredgecolor='white')
    ]
    legend = ax1.legend(custom_lines, ['Reward', 'Latency'],
                       loc='best', frameon=True, fancybox=True, framealpha=0.9,
                       shadow=True, fontsize=12, ncol=2)

    # Add sleek annotations for key points with stylish callouts
    max_reward_epoch = epochs[reward_mean.argmax()]
    min_latency_epoch = epochs[latency_mean.argmin()]

    # Create elegant annotation styles
    annotation_style = dict(
        boxstyle="round,pad=0.5",
        fc="#F8F8F8",
        ec="gray",
        alpha=0.9,
        lw=1
    )
    arrow_style = dict(
        arrowstyle="-|>",
        color='black',
        lw=1.5,
        connectionstyle="arc3,rad=0.2"
    )

    # Add stylish annotations for key points
    ax1.annotate(f'Peak Reward: {reward_mean.max():.2f}',
                xy=(max_reward_epoch, reward_mean.max()),
                xytext=(max_reward_epoch+8, reward_mean.max() + 0.2 * reward_mean.std().mean()),
                fontsize=11,
                bbox=annotation_style,
                arrowprops=arrow_style)

    ax2.annotate(f'Min Latency: {latency_mean.min():.2f}s',
                xy=(min_latency_epoch, latency_mean.min()),
                xytext=(min_latency_epoch+8, latency_mean.min() + 0.2 * latency_mean.std().mean()),
                fontsize=11,
                bbox=annotation_style,
                arrowprops=arrow_style)

    # Add subtle watermark
    fig.text(0.99, 0.01, 'Edge Computing Research',
             fontsize=8, color='gray',
             ha='right', va='bottom',
             alpha=0.5, style='italic')

    # Save with high quality settings and subtle border
    plt.tight_layout()
    for spine in ax1.spines.values():
        spine.set_edgecolor('#DDDDDD')  # Light gray border
    fig.savefig(os.path.join(output_dir, 'reward_latency_performance.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 2. PERFORMANCE METRICS PLOT - SEPARATE PLOTS FOR CLARITY
    # Create a figure with 3 subplots for better comparison with modern styling
    fig, axes = plt.subplots(3, 1, figsize=(12, 14), sharex=True)

    # Define metrics, labels and colors - using the premium color scheme
    metrics = ['deadline_violations', 'offload_ratio', 'cache_hit_ratio']
    labels = ['Deadline Violations', 'Offload Ratio', 'Cache Hit Ratio']
    colors = ['#D55E00', '#029E73', '#0173B2']  # premium colors from our palette

    # Create subplot background styling for elegant look
    for ax in axes:
        ax.set_facecolor('#FAFAFA')

    # Plot each metric in its own subplot with premium styling
    for i, (metric, label, color) in enumerate(zip(metrics, labels, colors)):
        ax = axes[i]

        # Create gradient effect for premium look
        x = epochs
        y = stats_df[metric]
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)

        # Create line collection with gradient colors - use appropriate colormap based on metric
        norm = plt.Normalize(0, 1)
        cmap_name = 'Reds_r' if 'violations' in metric else ('Blues' if 'cache' in metric else 'Greens')
        lc = LineCollection(segments, cmap=cmap_name, norm=norm)
        lc.set_array(np.linspace(0.3, 0.9, len(x)))
        lc.set_linewidth(3)
        line = ax.add_collection(lc)

        # Set y-range appropriately for better proportion and add elegant markers
        ax.set_xlim(x.min(), x.max())
        ax.set_ylim(0, stats_df[metric].max() * 1.1)

        # Add elegant markers with white outline
        marker_style = 'o' if i==1 else ('s' if i==0 else 'd')
        ax.scatter(x[::5], y[::5], color=color, s=70,
                  marker=marker_style, edgecolor='white', linewidth=1.5, zorder=3)

        # Add horizontal reference line with styling
        if 'ratio' in metric:
            ax.axhline(y=50, color='#888888', linestyle='--', alpha=0.4, lw=1, zorder=0)
            ax.axhline(y=75, color='#888888', linestyle=':', alpha=0.3, lw=1, zorder=0)
            ax.axhline(y=25, color='#888888', linestyle=':', alpha=0.3, lw=1, zorder=0)

        # Add elegant shading below the curve
        ax.fill_between(x, 0, y, color=color, alpha=0.08)

        # Add refined labels and styling
        ax.set_ylabel(f"{label} (%)", fontweight='medium', fontsize=14, labelpad=10)
        ax.grid(True, linestyle='--', alpha=0.2)

        # Add subtle annotation boxes for the final values
        last_value = y.iloc[-1]
        start_value = y.iloc[0]
        improvement = last_value - start_value

        # Create elegant annotation styles
        annotation_style = dict(
            boxstyle="round,pad=0.5",
            fc="#F8F8F8",
            ec=color,
            alpha=0.9,
            lw=1.5
        )

        # Add different text based on metric type
        if 'violation' in metric:
            text = f"Reduced by {abs(improvement):.1f}%"
            arrow_color = '#009900' if improvement < 0 else '#990000'
            improvement_icon = '↓' if improvement < 0 else '↑'
        else:
            text = f"Improved by {abs(improvement):.1f}%"
            arrow_color = '#009900' if improvement > 0 else '#990000'
            improvement_icon = '↑' if improvement > 0 else '↓'

        # Add value annotation with elegant styling
        ax.annotate(f"Final: {last_value:.1f}%",
                   xy=(x.iloc[-1], last_value),
                   xytext=(x.iloc[-1]-min(15, len(x)//2), last_value+5),
                   fontsize=12,
                   bbox=annotation_style)

        # Add improvement annotation with arrow
        # Calculate indices safely based on dataset size
        end_idx = max(0, min(len(x) - 1, len(x) - 10))
        text_idx = max(0, min(len(x) - 1, len(x) // 3))  # Use 1/3 of the way through dataset

        ax.annotate(f"{improvement_icon} {text}",
                   xy=(x.iloc[end_idx], (last_value + start_value)/2),
                   xytext=(x.iloc[text_idx], start_value + (improvement*0.7)),
                   fontsize=12,
                   color=arrow_color,
                   fontweight='medium',
                   bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=arrow_color, alpha=0.8),
                   arrowprops=dict(arrowstyle="-|>", color=arrow_color,
                                  connectionstyle="arc3,rad=-0.2", lw=2))

    # Set common x-axis label with elegant styling
    axes[-1].set_xlabel('Training Epoch', fontweight='medium', fontsize=14, labelpad=10)

    # Add overall title with premium styling
    title = 'Edge Computing Task Offloading Performance Metrics'
    fig.suptitle(title, fontsize=18, fontweight='medium', y=0.98)

    # Add subtle explanation text
    fig.text(0.5, 0.01, 'Note: Performance metrics showing improvements over training epochs',
             ha='center', fontsize=10, style='italic', alpha=0.7)

    # Adjust layout
    plt.tight_layout()
    plt.subplots_adjust(top=0.95, hspace=0.15)

    # Save figure with high quality
    plt.savefig(os.path.join(output_dir, 'performance_metrics_detailed.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 3. LEARNING DYNAMICS PLOT (LOSS COMPONENTS)
    fig, ax = plt.subplots(figsize=(12, 8), facecolor='#FAFAFA')
    ax.set_facecolor('#FAFAFA')

    # Use premium color palette for different loss types
    loss_types = ['policy_loss', 'value_loss', 'entropy_loss', 'total_loss']
    labels = ['Policy Loss', 'Value Loss', 'Entropy Loss', 'Total Loss']
    colors = ['#0173B2', '#DE8F05', '#029E73', '#D55E00']  # Premium colors
    markers = ['o', 's', 'd', '^']
    line_styles = ['-', '--', '-.', '-']

    # Create the plot with premium styling
    for loss_type, label, color, marker, ls in zip(loss_types, labels, colors, markers, line_styles):
        # Create gradient effect for premium look
        x = epochs
        y = stats_df[loss_type]
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)

        # Create line collection with gradient colors
        norm = plt.Normalize(0, 1)
        lc = LineCollection(segments, cmap=plt.cm.get_cmap(f'cividis'), norm=norm)
        lc.set_array(np.linspace(0.3, 0.9, len(x)))
        lc.set_linewidth(2.5)
        lc.set_linestyle(ls)
        line = ax.add_collection(lc)

        # Add elegant markers
        ax.scatter(x[::10], y[::10], color=color, s=60, marker=marker,
                  edgecolor='white', linewidth=1.5, zorder=3, label=label)

    # Set plot limits
    ax.set_xlim(epochs.min(), epochs.max())
    ax.set_ylim(stats_df[loss_types].min().min() * 0.8, stats_df[loss_types].max().max() * 1.2)

    # Use log scale for better visualization of loss convergence
    ax.set_yscale('log')

    # Add premium styling
    ax.set_xlabel('Training Epoch', fontweight='medium', fontsize=14)
    ax.set_ylabel('Loss Value (log scale)', fontweight='medium', fontsize=14)
    ax.set_title('MAPPO Training Convergence Analysis', fontsize=16, fontweight='medium', pad=15)

    # Create more elegant legend with custom styling
    legend = ax.legend(loc='upper right', frameon=True, fancybox=True, framealpha=0.9,
                      shadow=True, fontsize=12, ncol=2)
    legend.get_frame().set_edgecolor('#CCCCCC')

    # Add subtle grid for better readability
    ax.grid(True, which='both', linestyle='--', alpha=0.2)

    # Add annotations for convergence points
    converge_epoch = int(len(epochs) * 0.7)  # Assuming convergence at 70% of training

    # Create elegant annotation style
    annotation_style = dict(
        boxstyle="round,pad=0.5",
        fc="#F8F8F8",
        ec="#888888",
        alpha=0.9,
        lw=1
    )
    arrow_style = dict(
        arrowstyle="-|>",
        color='#888888',
        lw=1.5,
        connectionstyle="arc3,rad=0.2"
    )

    # Add a vertical line and annotation
    ax.axvline(x=converge_epoch, color='#888888', linestyle='--', alpha=0.7, lw=1.5)
    ax.annotate('Approximate Convergence Point',
               xy=(converge_epoch, stats_df['total_loss'].iloc[converge_epoch]),
               xytext=(converge_epoch-20, stats_df['total_loss'].iloc[converge_epoch]*3),
               fontsize=11,
               bbox=annotation_style,
               arrowprops=arrow_style)

    # Add insight annotation about loss relationships
    final_losses = stats_df.iloc[-1][loss_types]
    dominant_loss = final_losses.idxmax().split('_')[0].capitalize()

    # Calculate safe indices based on dataset size
    end_idx = max(0, min(len(epochs) - 1, len(epochs) - 10))
    text_idx = max(0, min(len(epochs) - 1, len(epochs) // 3))  # Use 1/3 of the way through dataset

    ax.annotate(f"{dominant_loss} remains the dominant component",
               xy=(epochs.iloc[end_idx], final_losses.max()),
               xytext=(epochs.iloc[text_idx], final_losses.max()*1.5),
               fontsize=11,
               bbox=annotation_style,
               arrowprops=arrow_style)

    # Add subtle watermark
    fig.text(0.99, 0.01, 'Edge Computing Research',
             fontsize=8, color='gray',
             ha='right', va='bottom',
             alpha=0.5, style='italic')

    # Save with high quality and subtle border
    plt.tight_layout()
    for spine in ax.spines.values():
        spine.set_edgecolor('#DDDDDD')

    plt.savefig(os.path.join(output_dir, 'training_convergence_analysis.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 4. COMBINED METRICS CORRELATION HEATMAP
    # Create correlation matrix to show relationships between metrics
    metrics_cols = ['reward_mean', 'latency_mean', 'deadline_violations',
                   'offload_ratio', 'cache_hit_ratio']

    # Create readable labels for the heatmap
    readable_labels = ['Reward', 'Latency', 'Deadline\nViolations', 'Offload\nRatio', 'Cache\nHit Ratio']

    corr_matrix = stats_df[metrics_cols].corr()

    # Plot the correlation heatmap with premium styling
    plt.figure(figsize=(10, 8), facecolor='#FAFAFA')

    # Create a more interesting mask for visual appeal
    mask = np.zeros_like(corr_matrix, dtype=bool)
    mask[np.triu_indices_from(mask, k=1)] = True

    # Generate a custom colormap with more sophisticated color palette
    cmap = sns.diverging_palette(230, 20, as_cmap=True)

    # Create elegant background with subtle grid
    ax = plt.gca()
    ax.set_facecolor('#FAFAFA')

    # Draw the heatmap with enhanced styling
    heatmap = sns.heatmap(corr_matrix,
                mask=mask,
                cmap=cmap,
                vmax=1,
                vmin=-1,
                center=0,
                square=True,
                linewidths=1,
                cbar_kws={"shrink": .8, "label": "Correlation Coefficient"},
                annot=True,
                fmt=".2f",
                annot_kws={"size": 13, "weight": "medium"})

    # Set elegant tick parameters
    plt.xticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=45, ha='right', fontsize=12)
    plt.yticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=0, fontsize=12)

    # Add premium styling to the colorbar
    cbar = heatmap.collections[0].colorbar
    cbar.ax.tick_params(labelsize=12)
    cbar.set_label('Correlation Coefficient', fontsize=13, fontweight='medium', labelpad=15)

    # Create prettier border for the figure
    for spine in plt.gca().spines.values():
        spine.set_visible(True)
        spine.set_color('#DDDDDD')

    # Add title with elegant styling
    plt.title('Metric Correlation Analysis', fontsize=16, fontweight='medium', pad=20)

    # Add informative subtitle with insights
    high_corr = corr_matrix.unstack().sort_values(ascending=False).drop_duplicates()[1:3]
    insight_text = f"Strongest relationship: {high_corr.index[0][0].split('_')[0].capitalize()} & {high_corr.index[0][1].split('_')[0].capitalize()} (r={high_corr.values[0]:.2f})"
    plt.figtext(0.5, 0.01, insight_text, ha='center', fontsize=12, fontweight='normal',
                bbox={'facecolor':'white', 'alpha':0.8, 'pad':5, 'edgecolor':'#DDDDDD'})

    # Add subtle watermark
    plt.figtext(0.95, 0.05, 'Edge Computing Research', fontsize=8, color='gray',
                ha='right', va='bottom', alpha=0.5, style='italic')

    # Save with high quality
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'metrics_correlation_heatmap.png'), dpi=600, bbox_inches='tight')
    plt.close()

    logger.info(f"Publication-quality training curves saved to {output_dir}")

def plot_evaluation_comparison(eval_results, output_dir='results/figures'):
    """
    Generate publication-quality comparison plots for evaluation results

    Args:
        eval_results: Dictionary of evaluation results for different models/settings
        output_dir: Directory to save figures
    """
    setup_plot_style()

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # Extract model names and metrics
    model_names = list(eval_results.keys())
    metrics = ['Reward', 'Latency (s)', 'Deadline Violations (%)',
               'Offload Ratio (%)', 'Cache Hit Ratio (%)']

    # Prepare data for plotting
    data = {metric: [] for metric in metrics}
    for model, results in eval_results.items():
        data['Reward'].append(results.get('reward_mean', 0))
        data['Latency (s)'].append(results.get('latency_mean', 0))
        data['Deadline Violations (%)'].append(results.get('deadline_violations_mean', 0))
        data['Offload Ratio (%)'].append(results.get('offload_ratio', 0))
        data['Cache Hit Ratio (%)'].append(results.get('cache_hit_ratio', 0))

    # 1. GROUPED BAR CHART - COMBINED VIEW OF ALL METRICS
    # This provides an overview of all metrics in one figure

    # Set up figure with professional styling
    fig, axs = plt.subplots(len(metrics), 1, figsize=(12, 15), sharex=True)

    # Color schemes for different types of metrics
    positive_colors = sns.color_palette("Blues_d", len(model_names))
    negative_colors = sns.color_palette("Reds_d", len(model_names))

    # Plot each metric as a subplot
    for i, metric in enumerate(metrics):
        ax = axs[i]

        # Choose colors based on the metric type
        if 'Violation' in metric or 'Latency' in metric:
            colors = negative_colors  # Lower is better
            # Add a "Lower is better" annotation
            ax.annotate('↓ Lower is better', xy=(0.02, 0.85), xycoords='axes fraction',
                      fontsize=12, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.8))
        else:
            colors = positive_colors  # Higher is better
            # Add a "Higher is better" annotation
            ax.annotate('↑ Higher is better', xy=(0.02, 0.85), xycoords='axes fraction',
                      fontsize=12, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.8))

        # Create bar plot with error margins
        bars = ax.bar(model_names, data[metric], color=colors, width=0.6, edgecolor='black', linewidth=1.5)

        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01 * max(data[metric]),
                   f'{height:.2f}', ha='center', va='bottom', fontsize=12, fontweight='bold')

        # Add professional styling
        ax.set_ylabel(metric, fontweight='bold')
        ax.grid(True, linestyle='--', alpha=0.7, axis='y')
        ax.set_title(f'Comparison of {metric}', fontsize=14, pad=10)

        # Add horizontal line for reference where appropriate
        if 'ratio' in metric.lower():
            ax.axhline(y=50, color='gray', linestyle='--', alpha=0.5)

        # Fill area below the curve for visual emphasis
        ax.fill_between(epochs, 0, stats_df[metric], color=color, alpha=0.15)

        # Add labels and styling
        ax.set_ylabel(f"{label} (%)", fontweight='bold')
        ax.grid(True, linestyle='--', alpha=0.7)

        # Add annotations for important trends
        last_value = stats_df[metric].iloc[-1]
        improvement = last_value - stats_df[metric].iloc[0]

        if 'violation' in metric:
            text = f"Final: {last_value:.1f}% (-{abs(improvement):.1f}%)"
        else:
            text = f"Final: {last_value:.1f}%"

        ax.annotate(text, xy=(epochs.iloc[-1], last_value),
                   xytext=(epochs.iloc[-1]-10, last_value+5),
                   fontsize=12, fontweight='bold')

    # Set common x-axis label
    axes[-1].set_xlabel('Training Epoch', fontweight='bold')

    # Add overall title
    fig.suptitle('Edge Computing Task Offloading Performance Metrics',
                fontsize=20, fontweight='bold', y=0.98)

    # Adjust layout
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)

    # Save figure
    plt.savefig(os.path.join(output_dir, 'performance_metrics_detailed.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 3. LEARNING DYNAMICS PLOT (LOSS COMPONENTS)
    plt.figure(figsize=(12, 8))

    # Use professional colors for different loss types
    loss_types = ['policy_loss', 'value_loss', 'entropy_loss', 'total_loss']
    labels = ['Policy Loss', 'Value Loss', 'Entropy Loss', 'Total Loss']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#7f7f7f']
    markers = ['o', 's', '^', 'd']

    # Create the plot with improved styling
    for loss_type, label, color, marker in zip(loss_types, labels, colors, markers):
        plt.plot(epochs, stats_df[loss_type], label=label, color=color, linewidth=2.5,
                marker=marker, markevery=10, markersize=8, markerfacecolor='white')

    # Use log scale for better visualization of loss convergence
    plt.yscale('log')

    # Add professional styling
    plt.xlabel('Training Epoch', fontweight='bold')
    plt.ylabel('Loss Value (log scale)', fontweight='bold')
    plt.title('MAPPO Training Convergence Analysis', fontsize=18, fontweight='bold', pad=20)

    # Create styled legend
    plt.legend(loc='upper right', frameon=True, fancybox=True, framealpha=0.9,
              shadow=True, fontsize=12)

    # Add grid for better readability
    plt.grid(True, which='both', linestyle='--', alpha=0.7)

    # Add annotations for convergence point
    converge_epoch = int(len(epochs) * 0.7)  # Assuming convergence at 70% of training
    plt.axvline(x=converge_epoch, color='red', linestyle='--', alpha=0.7)
    plt.annotate('Approximate Convergence',
                xy=(converge_epoch, stats_df['total_loss'].iloc[converge_epoch]),
                xytext=(converge_epoch+5, stats_df['total_loss'].iloc[converge_epoch]*2),
                arrowprops=dict(facecolor='black', shrink=0.05),
                fontsize=12)

    # Save with high quality
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'training_convergence_analysis.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 4. COMBINED METRICS CORRELATION HEATMAP
    # Create correlation matrix to show relationships between metrics
    metrics_cols = ['reward_mean', 'latency_mean', 'deadline_violations',
                   'offload_ratio', 'cache_hit_ratio']

    # Create readable labels for the heatmap
    readable_labels = ['Reward', 'Latency', 'Deadline\nViolations', 'Offload\nRatio', 'Cache\nHit Ratio']

    corr_matrix = stats_df[metrics_cols].corr()

    # Plot the correlation heatmap with premium styling
    plt.figure(figsize=(10, 8), facecolor='#FAFAFA')

    # Create a more interesting mask for visual appeal
    mask = np.zeros_like(corr_matrix, dtype=bool)
    mask[np.triu_indices_from(mask, k=1)] = True

    # Generate a custom colormap with more sophisticated color palette
    cmap = sns.diverging_palette(230, 20, as_cmap=True)

    # Create elegant background with subtle grid
    ax = plt.gca()
    ax.set_facecolor('#FAFAFA')

    # Draw the heatmap with enhanced styling
    heatmap = sns.heatmap(corr_matrix,
                mask=mask,
                cmap=cmap,
                vmax=1,
                vmin=-1,
                center=0,
                square=True,
                linewidths=1,
                cbar_kws={"shrink": .8, "label": "Correlation Coefficient"},
                annot=True,
                fmt=".2f",
                annot_kws={"size": 13, "weight": "medium"})

    # Set elegant tick parameters
    plt.xticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=45, ha='right', fontsize=12)
    plt.yticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=0, fontsize=12)

    # Add premium styling to the colorbar
    cbar = heatmap.collections[0].colorbar
    cbar.ax.tick_params(labelsize=12)
    cbar.set_label('Correlation Coefficient', fontsize=13, fontweight='medium', labelpad=15)

    # Create prettier border for the figure
    for spine in plt.gca().spines.values():
        spine.set_visible(True)
        spine.set_color('#DDDDDD')

    # Add title with elegant styling
    plt.title('Metric Correlation Analysis', fontsize=16, fontweight='medium', pad=20)

    # Add informative subtitle with insights
    high_corr = corr_matrix.unstack().sort_values(ascending=False).drop_duplicates()[1:3]
    insight_text = f"Strongest relationship: {high_corr.index[0][0].split('_')[0].capitalize()} & {high_corr.index[0][1].split('_')[0].capitalize()} (r={high_corr.values[0]:.2f})"
    plt.figtext(0.5, 0.01, insight_text, ha='center', fontsize=12, fontweight='normal',
                bbox={'facecolor':'white', 'alpha':0.8, 'pad':5, 'edgecolor':'#DDDDDD'})

    # Add subtle watermark
    plt.figtext(0.95, 0.05, 'Edge Computing Research', fontsize=8, color='gray',
                ha='right', va='bottom', alpha=0.5, style='italic')

    # Save with high quality
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'metrics_correlation_heatmap.png'), dpi=600, bbox_inches='tight')
    plt.close()

    logger.info(f"Publication-quality training curves saved to {output_dir}")

def plot_evaluation_comparison(eval_results, output_dir='results/figures'):
    """
    Generate publication-quality comparison plots for evaluation results

    Args:
        eval_results: Dictionary of evaluation results for different models/settings
        output_dir: Directory to save figures
    """
    setup_plot_style()

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # Extract model names and metrics
    model_names = list(eval_results.keys())
    metrics = ['Reward', 'Latency (s)', 'Deadline Violations (%)',
               'Offload Ratio (%)', 'Cache Hit Ratio (%)']

    # Prepare data for plotting
    data = {metric: [] for metric in metrics}
    for model, results in eval_results.items():
        data['Reward'].append(results.get('reward_mean', 0))
        data['Latency (s)'].append(results.get('latency_mean', 0))
        data['Deadline Violations (%)'].append(results.get('deadline_violations_mean', 0))
        data['Offload Ratio (%)'].append(results.get('offload_ratio', 0))
        data['Cache Hit Ratio (%)'].append(results.get('cache_hit_ratio', 0))

    # 1. GROUPED BAR CHART - COMBINED VIEW OF ALL METRICS
    # This provides an overview of all metrics in one figure

    # Set up figure with professional styling
    fig, axs = plt.subplots(len(metrics), 1, figsize=(12, 15), sharex=True)

    # Color schemes for different types of metrics
    positive_colors = sns.color_palette("Blues_d", len(model_names))
    negative_colors = sns.color_palette("Reds_d", len(model_names))

    # Plot each metric as a subplot
    for i, metric in enumerate(metrics):
        ax = axs[i]

        # Choose colors based on the metric type
        if 'Violation' in metric or 'Latency' in metric:
            colors = negative_colors  # Lower is better
            # Add a "Lower is better" annotation
            ax.annotate('↓ Lower is better', xy=(0.02, 0.85), xycoords='axes fraction',
                      fontsize=12, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.8))
        else:
            colors = positive_colors  # Higher is better
            # Add a "Higher is better" annotation
            ax.annotate('↑ Higher is better', xy=(0.02, 0.85), xycoords='axes fraction',
                      fontsize=12, bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.8))

        # Create bar plot with error margins
        bars = ax.bar(model_names, data[metric], color=colors, width=0.6, edgecolor='black', linewidth=1.5)

        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01 * max(data[metric]),
                   f'{height:.2f}', ha='center', va='bottom', fontsize=12, fontweight='bold')

        # Add professional styling
        ax.set_ylabel(metric, fontweight='bold')
        ax.grid(True, linestyle='--', alpha=0.7, axis='y')
        ax.set_title(f'Comparison of {metric}', fontsize=14, pad=10)

        # Add horizontal line for reference where appropriate
        if 'ratio' in metric.lower():
            ax.axhline(y=50, color='gray', linestyle='--', alpha=0.5)

        # Fill area below the curve for visual emphasis
        ax.fill_between(epochs, 0, stats_df[metric], color=color, alpha=0.15)

        # Add labels and styling
        ax.set_ylabel(f"{label} (%)", fontweight='bold')
        ax.grid(True, linestyle='--', alpha=0.7)

        # Add annotations for important trends
        last_value = stats_df[metric].iloc[-1]
        improvement = last_value - stats_df[metric].iloc[0]

        if 'violation' in metric:
            text = f"Final: {last_value:.1f}% (-{abs(improvement):.1f}%)"
        else:
            text = f"Final: {last_value:.1f}%"

        ax.annotate(text, xy=(epochs.iloc[-1], last_value),
                   xytext=(epochs.iloc[-1]-10, last_value+5),
                   fontsize=12, fontweight='bold')

    # Set common x-axis label
    axes[-1].set_xlabel('Training Epoch', fontweight='bold')

    # Add overall title
    fig.suptitle('Edge Computing Task Offloading Performance Metrics',
                fontsize=20, fontweight='bold', y=0.98)

    # Adjust layout
    plt.tight_layout()
    plt.subplots_adjust(top=0.95)

    # Save figure
    plt.savefig(os.path.join(output_dir, 'performance_metrics_detailed.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 3. LEARNING DYNAMICS PLOT (LOSS COMPONENTS)
    plt.figure(figsize=(12, 8))

    # Use professional colors for different loss types
    loss_types = ['policy_loss', 'value_loss', 'entropy_loss', 'total_loss']
    labels = ['Policy Loss', 'Value Loss', 'Entropy Loss', 'Total Loss']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#7f7f7f']
    markers = ['o', 's', '^', 'd']

    # Create the plot with improved styling
    for loss_type, label, color, marker in zip(loss_types, labels, colors, markers):
        plt.plot(epochs, stats_df[loss_type], label=label, color=color, linewidth=2.5,
                marker=marker, markevery=10, markersize=8, markerfacecolor='white')

    # Use log scale for better visualization of loss convergence
    plt.yscale('log')

    # Add professional styling
    plt.xlabel('Training Epoch', fontweight='bold')
    plt.ylabel('Loss Value (log scale)', fontweight='bold')
    plt.title('MAPPO Training Convergence Analysis', fontsize=18, fontweight='bold', pad=20)

    # Create styled legend
    plt.legend(loc='upper right', frameon=True, fancybox=True, framealpha=0.9,
              shadow=True, fontsize=12)

    # Add grid for better readability
    plt.grid(True, which='both', linestyle='--', alpha=0.7)

    # Add annotations for convergence point
    converge_epoch = int(len(epochs) * 0.7)  # Assuming convergence at 70% of training
    plt.axvline(x=converge_epoch, color='red', linestyle='--', alpha=0.7)
    plt.annotate('Approximate Convergence',
                xy=(converge_epoch, stats_df['total_loss'].iloc[converge_epoch]),
                xytext=(converge_epoch+5, stats_df['total_loss'].iloc[converge_epoch]*2),
                arrowprops=dict(facecolor='black', shrink=0.05),
                fontsize=12)

    # Save with high quality
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'training_convergence_analysis.png'), dpi=600, bbox_inches='tight')
    plt.close()

    # 4. COMBINED METRICS CORRELATION HEATMAP
    # Create correlation matrix to show relationships between metrics
    metrics_cols = ['reward_mean', 'latency_mean', 'deadline_violations',
                   'offload_ratio', 'cache_hit_ratio']

    # Create readable labels for the heatmap
    readable_labels = ['Reward', 'Latency', 'Deadline\nViolations', 'Offload\nRatio', 'Cache\nHit Ratio']

    corr_matrix = stats_df[metrics_cols].corr()

    # Plot the correlation heatmap with premium styling
    plt.figure(figsize=(10, 8), facecolor='#FAFAFA')

    # Create a more interesting mask for visual appeal
    mask = np.zeros_like(corr_matrix, dtype=bool)
    mask[np.triu_indices_from(mask, k=1)] = True

    # Generate a custom colormap with more sophisticated color palette
    cmap = sns.diverging_palette(230, 20, as_cmap=True)

    # Create elegant background with subtle grid
    ax = plt.gca()
    ax.set_facecolor('#FAFAFA')

    # Draw the heatmap with enhanced styling
    heatmap = sns.heatmap(corr_matrix,
                mask=mask,
                cmap=cmap,
                vmax=1,
                vmin=-1,
                center=0,
                square=True,
                linewidths=1,
                cbar_kws={"shrink": .8, "label": "Correlation Coefficient"},
                annot=True,
                fmt=".2f",
                annot_kws={"size": 13, "weight": "medium"})

    # Set elegant tick parameters
    plt.xticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=45, ha='right', fontsize=12)
    plt.yticks(np.arange(len(readable_labels)) + 0.5, readable_labels, rotation=0, fontsize=12)

    # Add premium styling to the colorbar
    cbar = heatmap.collections[0].colorbar
    cbar.ax.tick_params(labelsize=12)
    cbar.set_label('Correlation Coefficient', fontsize=13, fontweight='medium', labelpad=15)

    # Create prettier border for the figure
    for spine in plt.gca().spines.values():
        spine.set_visible(True)
        spine.set_color('#DDDDDD')

    # Add title with elegant styling
    plt.title('Metric Correlation Analysis', fontsize=16, fontweight='medium', pad=20)

    # Add informative subtitle with insights
    high_corr = corr_matrix.unstack().sort_values(ascending=False).drop_duplicates()[1:3]
    insight_text = f"Strongest relationship: {high_corr.index[0][0].split('_')[0].capitalize()} & {high_corr.index[0][1].split('_')[0].capitalize()} (r={high_corr.values[0]:.2f})"
    plt.figtext(0.5, 0.01, insight_text, ha='center', fontsize=12, fontweight='normal',
                bbox={'facecolor':'white', 'alpha':0.8, 'pad':5, 'edgecolor':'#DDDDDD'})

    # Add subtle watermark
    plt.figtext(0.95, 0.05, 'Edge Computing Research', fontsize=8, color='gray',
                ha='right', va='bottom', alpha=0.5, style='italic')

    # Save with high quality
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'metrics_correlation_heatmap.png'), dpi=600, bbox_inches='tight')
    plt.close()

    logger.info(f"Publication-quality training curves saved to {output_dir}")

def visualize_results(stats_path, output_dir='results/figures'):
    """
    Entry point for visualization

    Args:
        stats_path (str): Path to statistics file
        output_dir (str): Directory to save figures
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    try:
        # Load statistics
        if isinstance(stats_path, str) and stats_path.endswith('.csv'):
            stats_df = pd.read_csv(stats_path)
            plot_training_curves(stats_df, output_dir)
            logger.info(f"Generated training visualization from {stats_path}")

        elif isinstance(stats_path, dict):
            # If passed directly as evaluation results dictionary
            plot_evaluation_comparison(stats_path, output_dir)
            logger.info("Generated evaluation comparison visualization")

        elif isinstance(stats_path, str) and (stats_path.endswith('.json') or stats_path.endswith('.pkl')):
            # Load evaluation results from file
            if stats_path.endswith('.json'):
                import json
                with open(stats_path, 'r') as f:
                    eval_results = json.load(f)
            else:
                import pickle
                with open(stats_path, 'rb') as f:
                    eval_results = pickle.load(f)

            plot_evaluation_comparison(eval_results, output_dir)
            logger.info(f"Generated evaluation visualization from {stats_path}")

        else:
            logger.error(f"Unsupported stats file format: {stats_path}")

    except Exception as e:
        logger.error(f"Error visualizing results: {e}")
        raise

if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)

    # Test with sample data
    stats = {
        'epoch': list(range(1, 101)),
        'reward_mean': np.random.normal(-5, 1, 100).cumsum() / 20,
        'reward_std': np.random.uniform(0.5, 1.5, 100),
        'latency_mean': np.random.normal(0, 0.1, 100).cumsum() + 0.5,
        'latency_std': np.random.uniform(0.05, 0.2, 100),
        'deadline_violations': 100 * np.exp(-np.linspace(0, 3, 100)),
        'offload_ratio': 20 + 60 * (1 - np.exp(-np.linspace(0, 5, 100))),
        'cache_hit_ratio': 10 + 75 * (1 - np.exp(-np.linspace(0, 3, 100))),
        'policy_loss': 2 * np.exp(-np.linspace(0, 3, 100)),
        'value_loss': 5 * np.exp(-np.linspace(0, 4, 100)),
        'entropy_loss': np.random.normal(0.2, 0.05, 100),
        'total_loss': 8 * np.exp(-np.linspace(0, 3.5, 100))
    }

    stats_df = pd.DataFrame(stats)
    output_dir = 'results/figures/test'

    visualize_results(stats_df, output_dir)
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

sns.set(style='whitegrid')

def plot_comparison(csv_paths, labels, metric_key, title, ylabel, save_path=None):
    plt.figure(figsize=(10, 6))

    for csv_path, label in zip(csv_paths, labels):
        df = pd.read_csv(csv_path)
        if metric_key in df.columns:
            plt.plot(df['epoch'], df[metric_key], label=label)

    plt.title(title)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.legend()
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path)
        print(f"Saved: {save_path}")
    else:
        plt.show()

def compare_all(csv_paths, labels, output_dir="visualizations_comparison"):
    plot_comparison(csv_paths, labels, 'reward', "Reward vs Epoch", "Total Reward", f"{output_dir}/reward_vs_epoch.png")
    plot_comparison(csv_paths, labels, 'avg_latency', "Average Latency vs Epoch", "Latency (ms)", f"{output_dir}/latency_vs_epoch.png")
    plot_comparison(csv_paths, labels, 'deadlines_met', "Deadlines Met vs Epoch", "Deadlines Met", f"{output_dir}/deadlines_vs_epoch.png")
    plot_comparison(csv_paths, labels, 'loss', "Total Loss vs Epoch", "Loss", f"{output_dir}/loss_vs_epoch.png")
    plot_comparison(csv_paths, labels, 'estimated_cost', "Estimated Offloading Cost vs Epoch", "Cost ($)", f"{output_dir}/cost_vs_epoch.png")
    plot_comparison(csv_paths, labels, 'inference_time', "Inference Time vs Epoch", "Inference Time (ms)", f"{output_dir}/inference_vs_epoch.png")

# Example usage:
if __name__ == "__main__":
    import os

    compare_all(
        csv_paths=[
            "../../results/metrics_mappo_20250406_190719.csv",
            "../../results/metrics_dqn_20250406_214526.csv"
        ],
        labels=["MAPPO", "DQN"]
    )
