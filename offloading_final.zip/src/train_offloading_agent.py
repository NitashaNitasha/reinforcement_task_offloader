import os
import time
import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import logging
from datetime import datetime
import yaml
from tensorboard import program

import threading
from src.utils.performance_metrics import log_metrics_to_csv
from src.agents.mappo_agent import MAPPOAgent
from src.agents.dqn_agent import DQNAgent
from src.environment.edge_environment import EdgeComputingEnvironment

logger = logging.getLogger(__name__)


def train_dqn(agent, env, config):
    n_episodes = config['training']['epochs']
    max_steps = config['environment']['simulation_steps']

    for episode in range(n_episodes):
        state = env.reset()
        episode_reward = 0

        for step in range(max_steps):
            action = agent.select_action(state)

            # Convert the single action to a list for the environment
            actions = [action]

            next_state, rewards, done, _ = env.step(actions)

            # Since rewards is a list, take the first element
            reward = rewards[0]  # Take the first reward from the list

            agent.store_transition(state, action, reward, next_state, done)
            agent.train_step()

            state = next_state
            episode_reward += reward

            if done:
                break

        print(f"[Episode {episode + 1}] Total Reward: {episode_reward:.2f}, Epsilon: {agent.epsilon:.3f}")


def train_agent(agent, env, config):
    """
    Train the MAPPO agent
    
    Args:
        agent (MAPPOAgent): Agent to train
        env (EdgeComputingEnvironment): Training environment
        config (dict): Configuration dictionary
        
    Returns:
        training_info (dict): Training metrics
    """
    # Extract training parameters
    epochs = config['training']['epochs']
    update_interval = config['training']['update_interval']
    n_updates_per_iter = config['training']['n_updates_per_iter']
    test_interval = config['training']['test_interval']
    save_interval = config['training']['save_interval']
    model_dir = config['training']['model_dir']
    
    # Create directories
    os.makedirs(model_dir, exist_ok=True)
    
    # Create stats trackers
    stats = {
        'epoch': [],
        'reward_mean': [],
        'reward_std': [],
        'latency_mean': [],
        'latency_std': [],
        'deadline_violations': [],
        'offload_ratio': [],
        'cache_hit_ratio': [],
        'policy_loss': [],
        'value_loss': [],
        'entropy_loss': [],
        'total_loss': []
    }
    
    # Set up tensorboard if available
    tb_writer = None
    try:
        from torch.utils.tensorboard import SummaryWriter
        log_dir = config['training']['log_dir']
        os.makedirs(log_dir, exist_ok=True)
        tb_writer = SummaryWriter(log_dir=os.path.join(log_dir, f"run_{int(time.time())}"))
        
        # Start tensorboard in background if available
        def start_tensorboard():
            try:
                # Check for required dependencies
                try:
                    import imghdr
                except ImportError:
                    logger.warning("Missing 'imghdr' module required by TensorBoard. Skipping TensorBoard server startup.")
                    return
                
                tb = program.TensorBoard()
                tb.configure(argv=[None, '--logdir', log_dir])
                url = tb.launch()
                logger.info(f"TensorBoard started at {url}")
            except Exception as e:
                logger.warning(f"Failed to start TensorBoard: {e}")
                
        threading.Thread(target=start_tensorboard, daemon=True).start()
    except (ImportError, KeyError):
        logger.warning("TensorBoard not available, training progress will not be visualized")
    
    # Start training
    logger.info(f"Starting training for {epochs} epochs")
    start_time = time.time()
    
    # Get initial state
    states = env.reset()
    agent.reset_lstm_states()
    
    # Training loop
    for epoch in range(1, epochs + 1):
        epoch_rewards = []
        epoch_latencies = []
        epoch_deadline_violations = []
        
        # Reset environment at the start of each epoch
        states = env.reset()
        agent.reset_lstm_states()
        
        # Collect experience
        for step in tqdm(range(update_interval), desc=f"Epoch {epoch}/{epochs}", leave=False):
            # Select actions
            actions, log_probs, values = agent.act(states)
            
            # Execute actions
            next_states, rewards, dones, info = env.step(actions)
            
            # Store experience
            agent_ids = list(range(agent.n_agents))
            agent.store_transition(
                agent_ids=agent_ids,
                states=states,
                actions=actions,
                log_probs=log_probs,
                rewards=rewards,
                values=values,
                dones=dones
            )
            
            # Update states
            states = next_states
            
            # Reset LSTM states if done
            if any(dones):
                agent.reset_lstm_states()
            
            # Collect statistics
            epoch_rewards.extend(rewards)
            epoch_latencies.extend(info['latencies'])
            epoch_deadline_violations.extend(info['deadline_violations'])
        
        # Get next values for GAE calculation
        _, _, next_values = agent.act(states)
        
        # Update policy
        update_info = {}
        for _ in range(n_updates_per_iter):
            update_results = agent.update(next_values)
            
            # Aggregate update info
            for key, value in update_results.items():
                if key not in update_info:
                    update_info[key] = []
                update_info[key].append(value)
        
        # Calculate average update metrics
        update_info = {key: np.mean(value) for key, value in update_info.items()}
        
        # Calculate epoch statistics
        reward_mean = np.mean(epoch_rewards)
        reward_std = np.std(epoch_rewards)
        latency_mean = np.mean(epoch_latencies)
        latency_std = np.std(epoch_latencies)
        deadline_violations = np.mean(epoch_deadline_violations) * 100  # As percentage
        
        # Get environment metrics
        env_metrics = env.get_metrics()
        offload_ratio = env_metrics['offload_ratio'] * 100  # As percentage
        cache_hit_ratio = env_metrics['cache_hit_ratio'] * 100  # As percentage
        
        # Log statistics
        logger.info(f"Epoch {epoch}/{epochs} - " +
                   f"Reward: {reward_mean:.2f} ± {reward_std:.2f}, " +
                   f"Latency: {latency_mean:.4f} ± {latency_std:.4f}, " +
                   f"Deadline Violations: {deadline_violations:.1f}%, " +
                   f"Offload Ratio: {offload_ratio:.1f}%, " +
                   f"Cache Hit Ratio: {cache_hit_ratio:.1f}%")
        
        # Record statistics
        stats['epoch'].append(epoch)
        stats['reward_mean'].append(reward_mean)
        stats['reward_std'].append(reward_std)
        stats['latency_mean'].append(latency_mean)
        stats['latency_std'].append(latency_std)
        stats['deadline_violations'].append(deadline_violations)
        stats['offload_ratio'].append(offload_ratio)
        stats['cache_hit_ratio'].append(cache_hit_ratio)
        stats['policy_loss'].append(update_info.get('policy_loss', 0.0))
        stats['value_loss'].append(update_info.get('value_loss', 0.0))
        stats['entropy_loss'].append(update_info.get('entropy_loss', 0.0))
        stats['total_loss'].append(update_info.get('total_loss', 0.0))
        
        # Write to TensorBoard if available
        if tb_writer:
            tb_writer.add_scalar('Reward/mean', reward_mean, epoch)
            tb_writer.add_scalar('Latency/mean', latency_mean, epoch)
            tb_writer.add_scalar('Metrics/deadline_violations', deadline_violations, epoch)
            tb_writer.add_scalar('Metrics/offload_ratio', offload_ratio, epoch)
            tb_writer.add_scalar('Metrics/cache_hit_ratio', cache_hit_ratio, epoch)
            for loss_name, loss_val in update_info.items():
                tb_writer.add_scalar(f'Loss/{loss_name}', loss_val, epoch)
        
        # Evaluate and save model
        if epoch % test_interval == 0 or epoch == epochs:
            # Test performance
            test_metrics = evaluate_agent(agent, env, config, n_episodes=5, verbose=False)
            logger.info(f"Test metrics: {test_metrics}")
            
            if tb_writer:
                for metric_name, metric_val in test_metrics.items():
                    tb_writer.add_scalar(f'Test/{metric_name}', metric_val, epoch)
        
        # Save model checkpoint
        if epoch % save_interval == 0 or epoch == epochs:
            checkpoint_path = os.path.join(model_dir, f"agent_{epoch}.pth")
            agent.save_checkpoint(checkpoint_path)
            logger.info(f"Model saved to {checkpoint_path}")
    
    # Save final model
    final_path = os.path.join(model_dir, "agent_final.pth")
    agent.save_checkpoint(final_path)
    logger.info(f"Final model saved to {final_path}")
    
    # Save training statistics
    stats_df = pd.DataFrame(stats)
    stats_path = os.path.join(model_dir, "training_stats.csv")
    stats_df.to_csv(stats_path, index=False)
    logger.info(f"Training statistics saved to {stats_path}")
    
    # Close TensorBoard writer if used
    if tb_writer:
        tb_writer.close()
    
    # Calculate total training time
    training_time = time.time() - start_time
    hours, rem = divmod(training_time, 3600)
    minutes, seconds = divmod(rem, 60)
    logger.info(f"Training completed in {int(hours)}h {int(minutes)}m {seconds:.1f}s")
    
    return stats


def evaluate_agent(agent, env, config, n_episodes=20, verbose=True):
    """
    Evaluate a trained agent
    
    Args:
        agent (MAPPOAgent): Agent to evaluate
        env (EdgeComputingEnvironment): Evaluation environment
        config (dict): Configuration dictionary
        n_episodes (int): Number of episodes to evaluate
        verbose (bool): Whether to print evaluation progress
        
    Returns:
        metrics (dict): Evaluation metrics
    """
    # Turn on evaluation mode
    deterministic = config.get('evaluation', {}).get('deterministic', True)
    
    # Reset metrics
    rewards = []
    latencies = []
    deadline_violations = []
    
    # Evaluate for n_episodes
    if verbose:
        logger.info(f"Evaluating agent for {n_episodes} episodes...")
    
    for episode in range(1, n_episodes + 1):
        episode_rewards = []
        episode_latencies = []
        episode_deadline_violations = []
        
        # Reset environment
        states = env.reset()
        agent.reset_lstm_states()
        
        # Run episode
        done = False
        while not done:
            # Select actions
            actions, _, _ = agent.act(states)
            
            # Execute actions
            next_states, episode_reward, dones, info = env.step(actions)
            
            # Update states
            states = next_states
            done = any(dones)
            
            # Collect statistics
            episode_rewards.extend(episode_reward)
            episode_latencies.extend(info['latencies'])
            episode_deadline_violations.extend(info['deadline_violations'])
        
        # Record episode statistics
        rewards.append(np.mean(episode_rewards))
        latencies.append(np.mean(episode_latencies))
        deadline_violations.append(np.mean(episode_deadline_violations) * 100)  # As percentage
        
        if verbose and episode % 5 == 0:
            logger.info(f"Episode {episode}/{n_episodes} - " +
                       f"Reward: {rewards[-1]:.2f}, " +
                       f"Latency: {latencies[-1]:.4f}, " +
                       f"Deadline Violations: {deadline_violations[-1]:.1f}%")
    
    # Get environment metrics
    env_metrics = env.get_metrics()
    offload_ratio = env_metrics['offload_ratio'] * 100
    cache_hit_ratio = env_metrics['cache_hit_ratio'] * 100
    
    # Calculate statistics
    metrics = {
        'reward_mean': np.mean(rewards),
        'reward_std': np.std(rewards),
        'latency_mean': np.mean(latencies),
        'latency_std': np.std(latencies),
        'deadline_violations_mean': np.mean(deadline_violations),
        'offload_ratio': offload_ratio,
        'cache_hit_ratio': cache_hit_ratio
    }
    
    if verbose:
        logger.info("Evaluation Results:")
        logger.info(f"Reward: {metrics['reward_mean']:.2f} ± {metrics['reward_std']:.2f}")
        logger.info(f"Latency: {metrics['latency_mean']:.4f} ± {metrics['latency_std']:.4f}")
        logger.info(f"Deadline Violations: {metrics['deadline_violations_mean']:.1f}%")
        logger.info(f"Offload Ratio: {metrics['offload_ratio']:.1f}%")
        logger.info(f"Cache Hit Ratio: {metrics['cache_hit_ratio']:.1f}%")
    
    return metrics


def visualize_training_results(stats_path='models/training_stats.csv', output_dir='results/figures'):
    """
    Visualize training results
    
    Args:
        stats_path (str): Path to training statistics CSV
        output_dir (str): Directory to save figures
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Load statistics
    try:
        stats = pd.read_csv(stats_path)
    except FileNotFoundError:
        logger.error(f"Statistics file not found: {stats_path}")
        return
    
    # Set style
    sns.set(style="whitegrid")
    plt.rcParams.update({'font.size': 12})
    
    # 1. Reward and Latency plot
    fig, ax1 = plt.subplots(figsize=(12, 6))
    
    color = 'tab:blue'
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Reward', color=color)
    ax1.plot(stats['epoch'], stats['reward_mean'], color=color, label='Reward')
    ax1.fill_between(
        stats['epoch'],
        stats['reward_mean'] - stats['reward_std'],
        stats['reward_mean'] + stats['reward_std'],
        color=color, alpha=0.2
    )
    ax1.tick_params(axis='y', labelcolor=color)
    
    ax2 = ax1.twinx()
    color = 'tab:red'
    ax2.set_ylabel('Latency (s)', color=color)
    ax2.plot(stats['epoch'], stats['latency_mean'], color=color, label='Latency')
    ax2.fill_between(
        stats['epoch'],
        stats['latency_mean'] - stats['latency_std'],
        stats['latency_mean'] + stats['latency_std'],
        color=color, alpha=0.2
    )
    ax2.tick_params(axis='y', labelcolor=color)
    
    fig.tight_layout()
    plt.title('Reward and Latency during Training')
    
    # Add legends
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='best')
    
    plt.savefig(os.path.join(output_dir, 'reward_latency.png'), dpi=300, bbox_inches='tight')
    
    # 2. Metrics plot
    plt.figure(figsize=(12, 6))
    plt.plot(stats['epoch'], stats['deadline_violations'], label='Deadline Violations (%)')
    plt.plot(stats['epoch'], stats['offload_ratio'], label='Offload Ratio (%)')
    plt.plot(stats['epoch'], stats['cache_hit_ratio'], label='Cache Hit Ratio (%)')
    plt.xlabel('Epoch')
    plt.ylabel('Percentage')
    plt.title('Training Metrics')
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(output_dir, 'metrics.png'), dpi=300, bbox_inches='tight')
    
    # 3. Loss plot
    plt.figure(figsize=(12, 6))
    plt.plot(stats['epoch'], stats['policy_loss'], label='Policy Loss')
    plt.plot(stats['epoch'], stats['value_loss'], label='Value Loss')
    plt.plot(stats['epoch'], stats['entropy_loss'], label='Entropy Loss')
    plt.plot(stats['epoch'], stats['total_loss'], label='Total Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Losses')
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(output_dir, 'losses.png'), dpi=300, bbox_inches='tight')
    
    logger.info(f"Training visualizations saved to {output_dir}")


def visualize_results(stats_path, output_dir='results/figures'):
    """
    Entry point for visualization
    
    Args:
        stats_path (str): Path to statistics file
        output_dir (str): Directory to save figures
    """
    visualize_training_results(stats_path, output_dir)


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Load configuration
    with open('experiments/default_config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    
    # Create environment
    env = EdgeComputingEnvironment(
        dataset_path=config['environment']['dataset_path'],
        use_cache=config['environment']['use_cache'],
        simulation_steps=config['environment']['simulation_steps'],
        batch_size=config['environment']['batch_size']
    )
    
    # Create agent
    agent = MAPPOAgent(
        observation_space=env.observation_space,
        action_space=env.action_space,
        n_agents=config['agent']['n_agents'],
        learning_rate=config['agent']['learning_rate'],
        hidden_dim=config['agent']['hidden_dim'],
        lstm_dim=config['agent']['lstm_dim']
    )
    
    # Train agent
    train_agent(agent, env, config)


def train_agent_with_per_epoch_metrics(agent, env, config, base_metrics, metrics_file=None):
    """
    Train an agent with per-epoch metrics logging.

    Args:
        agent: The reinforcement learning agent to train
        env: The environment to train in
        config: Training configuration
        base_metrics: Base metrics to include in every epoch
        metrics_file: File to save metrics to

    Returns:
        dict: Metrics for the final epoch
    """
    # Training hyperparameters
    n_episodes = config.get('episodes', 100)
    max_steps_per_episode = config.get('steps', 1000)

    # Performance tracking
    all_rewards = []
    avg_rewards = []

    # For each episode
    for epoch in range(n_episodes):
        start_time = time.time()

        # Reset the environment
        states = env.reset()
        agent.reset_lstm_states()

        episode_rewards = []
        total_reward = 0
        done = False
        steps = 0

        # Run the episode
        while not done and steps < max_steps_per_episode:
            # Get the active agents based on environment state

            agent_ids = list(range(agent.n_agents))


            # If no agents are active, break
            if not agent_ids:
                break

            # Get states for active agents
            agent_states = [states[i] for i in agent_ids]

            # Select actions
            actions, log_probs, values = agent.act(agent_states, agent_ids)

            # Take step in the environment
            next_states, rewards, dones, info = env.step(actions)

            # Store transition in agent buffer
            agent.store_transition(
                agent_ids, agent_states, actions, log_probs, rewards, values, dones
            )

            # Update states and accumulate rewards
            states = next_states
            episode_rewards.extend(rewards)
            total_reward = sum(rewards) / len(rewards)

            # Check if episode is done
            done = all(dones) if isinstance(dones, list) else dones
            steps += 1

            # Update agent (e.g., for on-policy methods like PPO)
            if hasattr(agent, 'update_frequency') and steps % agent.update_frequency == 0:
                # Get next state values
                with torch.no_grad():
                    next_active_agents = env.get_active_agents()
                    next_agent_ids = [i for i in range(len(next_active_agents)) if next_active_agents[i]]
                    next_agent_states = [states[i] for i in next_agent_ids]

                    if next_agent_ids:
                        _, _, next_values = agent.act(next_agent_states, next_agent_ids)
                    else:
                        next_values = [0.0] * len(agent_ids)

                # Update the agent
                update_info = agent.update(next_values)

        # Final update at the end of the episode
        next_values = [0.0] * agent.n_agents  # Assume zero value for terminal state
        update_info = agent.update(next_values)

        # Record metrics
        epoch_time = time.time() - start_time

        # Create metrics dictionary
        epoch_metrics = {
            'epoch': epoch,
            'reward': total_reward,  # Total reward for the episode
        }

        # Add loss metrics based on update_info
        if update_info and len(update_info) > 0:
            # Calculate average metrics across all agents
            epoch_metrics.update({
                'policy_loss': sum(info.get('policy_loss', 0.0) for info in update_info) / len(update_info),
                'value_loss': sum(info.get('value_loss', 0.0) for info in update_info) / len(update_info),
                'entropy_loss': sum(info.get('entropy_loss', 0.0) for info in update_info) / len(update_info),
            })

            # Calculate total loss as a combination of individual losses
            avg_policy_loss = sum(info.get('policy_loss', 0.0) for info in update_info) / len(update_info)
            avg_value_loss = sum(info.get('value_loss', 0.0) for info in update_info) / len(update_info)
            avg_entropy_loss = sum(info.get('entropy_loss', 0.0) for info in update_info) / len(update_info)
            epoch_metrics['total_loss'] = avg_policy_loss + avg_value_loss - avg_entropy_loss
        else:
            # Default values when no update info is available
            epoch_metrics.update({
                'policy_loss': 0.0,
                'value_loss': 0.0,
                'entropy_loss': 0.0,
                'total_loss': 0.0,
            })

        # Add remaining metrics
        epoch_metrics['training_time'] = epoch_time
        epoch_metrics.update(base_metrics)  # Include the base metrics

        # Optional: Log individual agent metrics for detailed analysis
        if update_info:
            for i, agent_info in enumerate(update_info):
                agent_metrics = {
                    f'agent_{i}_policy_loss': agent_info.get('policy_loss', 0.0),
                    f'agent_{i}_value_loss': agent_info.get('value_loss', 0.0),
                    f'agent_{i}_entropy_loss': agent_info.get('entropy_loss', 0.0),
                }
                epoch_metrics.update(agent_metrics)

        # Add to tracking metrics
        all_rewards.append(total_reward)
        avg_rewards.append(sum(all_rewards[-100:]) / min(len(all_rewards), 100))

        # Log metrics to file if provided
        if metrics_file:
            log_metrics_to_csv(epoch_metrics, metrics_file)

        # Print progress
        if epoch % 10 == 0 or epoch == n_episodes - 1:
            print(f"Episode {epoch}/{n_episodes}, Reward: {total_reward:.2f}, "
                  f"Avg Reward (100): {avg_rewards[-1]:.2f}, Time: {epoch_time:.2f}s")

    return epoch_metrics

def train_dqn_with_per_epoch_metrics(agent, env, config, base_metrics, metrics_file):
    """
    Train a DQN agent with metrics collected for each epoch.

    Args:
        agent: The DQN agent to train
        env: The environment to train in
        config: Configuration dictionary
        base_metrics: Dictionary of metrics that remain constant across epochs
        metrics_file: Path to save the metrics CSV file

    Returns:
        Dictionary containing lists of per-epoch metrics
    """
    import time
    import csv
    import os
    from collections import defaultdict

    # Ensure directory exists
    os.makedirs(os.path.dirname(metrics_file), exist_ok=True)

    # Initialize CSV file with headers
    with open(metrics_file, 'w', newline='') as f:
        fieldnames = [
            'epoch', 'reward', 'epsilon', 'loss', 'training_time',
            'agent_type', 'params', 'inference_time', 'estimated_cost',
            'steps_per_episode', 'n_agents'
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

    n_epochs = config['training']['epochs']
    steps_per_episode = config['environment']['simulation_steps']
    all_metrics = defaultdict(list)

    for epoch in range(1, n_epochs + 1):
        epoch_start_time = time.time()
        state = env.reset()
        done = False
        total_reward = 0
        losses = []
        episode_step = 0

        # Execute one episode
        while not done and episode_step < steps_per_episode:
            # DQN action selection
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step([action])

            agent.store_transition(state, action, reward, next_state, done)
            loss = agent.train_step()

            if loss is not None:
                losses.append(loss)

            state = next_state
            total_reward += reward[0]
            episode_step += 1

        # Calculate epoch metrics
        epoch_time = time.time() - epoch_start_time
        avg_loss = sum(losses) / len(losses) if losses else 0

        # Collect metrics for this epoch
        epoch_metrics = {
            'epoch': epoch,
            'reward': total_reward,
            'epsilon': agent.epsilon if hasattr(agent, 'epsilon') else 0,
            'loss': avg_loss,
            'training_time': epoch_time,
            **base_metrics  # Include the base metrics
        }

        # Log metrics to console
        print(f"[Episode {epoch}] Total Reward: {total_reward:.2f}, "
              f"Epsilon: {epoch_metrics['epsilon']:.3f}, "
              f"Time: {epoch_time:.2f}s")

        # Append to CSV
        with open(metrics_file, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writerow(epoch_metrics)

        # Store metrics for return
        for key, value in epoch_metrics.items():
            all_metrics[key].append(value)

        # Update epsilon according to decay schedule
        if hasattr(agent, 'decay_epsilon'):
            agent.decay_epsilon()

    return dict(all_metrics)  # Convert defaultdict to regular dict for return